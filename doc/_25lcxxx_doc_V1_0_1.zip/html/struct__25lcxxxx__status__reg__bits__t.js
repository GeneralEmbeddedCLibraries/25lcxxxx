var struct__25lcxxxx__status__reg__bits__t =
[
    [ "bp", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gaaccbd2a5e8a7f68cffeecae67b6c87d7", null ],
    [ "res", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gac16f015eede2270fa3f7217efc992d00", null ],
    [ "wel", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gab94751fc4f915f01369b87db72d0e247", null ],
    [ "wip", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga72e3fb6a65d40b0b25f75ba52926ebcf", null ],
    [ "wpen", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga5e75c42b432940c9492406df2eb35987", null ]
];