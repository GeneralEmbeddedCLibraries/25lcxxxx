var modules =
[
    [ "_25LCXXXX_API", "group____25_l_c_x_x_x_x___a_p_i.html", "group____25_l_c_x_x_x_x___a_p_i" ],
    [ "KERNEL_FUNCTIONS", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s" ],
    [ "_25LCXXXX_REGEDEF", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f" ]
];