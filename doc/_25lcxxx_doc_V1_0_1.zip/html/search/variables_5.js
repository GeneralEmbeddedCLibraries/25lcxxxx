var searchData=
[
  ['res_99',['res',['../group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gac16f015eede2270fa3f7217efc992d00',1,'_25lcxxxx_status_reg_bits_t']]]
];
