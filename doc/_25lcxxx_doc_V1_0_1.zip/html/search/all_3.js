var searchData=
[
  ['b_37',['b',['../group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gad98331d66a4188a4163838c07855e419',1,'_25lcxxxx_status_reg_t']]],
  ['bp_38',['bp',['../group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gaaccbd2a5e8a7f68cffeecae67b6c87d7',1,'_25lcxxxx_status_reg_bits_t']]]
];
