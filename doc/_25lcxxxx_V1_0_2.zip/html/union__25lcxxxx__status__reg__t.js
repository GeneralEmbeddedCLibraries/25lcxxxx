var union__25lcxxxx__status__reg__t =
[
    [ "b", "union__25lcxxxx__status__reg__t.html#ad98331d66a4188a4163838c07855e419", null ],
    [ "u", "union__25lcxxxx__status__reg__t.html#a0d32dd6d63eb9497d1b3bbca6e2a614b", null ]
];