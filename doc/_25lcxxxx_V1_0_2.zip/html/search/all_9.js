var searchData=
[
  ['res_63',['res',['../struct__25lcxxxx__status__reg__bits__t.html#ac16f015eede2270fa3f7217efc992d00',1,'_25lcxxxx_status_reg_bits_t']]]
];
