var searchData=
[
  ['b_37',['b',['../union__25lcxxxx__status__reg__t.html#ad98331d66a4188a4163838c07855e419',1,'_25lcxxxx_status_reg_t']]],
  ['bp_38',['bp',['../struct__25lcxxxx__status__reg__bits__t.html#aaccbd2a5e8a7f68cffeecae67b6c87d7',1,'_25lcxxxx_status_reg_bits_t']]]
];
