var struct__25lcxxxx__status__reg__bits__t =
[
    [ "bp", "struct__25lcxxxx__status__reg__bits__t.html#aaccbd2a5e8a7f68cffeecae67b6c87d7", null ],
    [ "res", "struct__25lcxxxx__status__reg__bits__t.html#ac16f015eede2270fa3f7217efc992d00", null ],
    [ "wel", "struct__25lcxxxx__status__reg__bits__t.html#ab94751fc4f915f01369b87db72d0e247", null ],
    [ "wip", "struct__25lcxxxx__status__reg__bits__t.html#a72e3fb6a65d40b0b25f75ba52926ebcf", null ],
    [ "wpen", "struct__25lcxxxx__status__reg__bits__t.html#a5e75c42b432940c9492406df2eb35987", null ]
];