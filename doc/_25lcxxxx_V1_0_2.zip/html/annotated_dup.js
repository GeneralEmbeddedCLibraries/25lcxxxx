var annotated_dup =
[
    [ "_25lcxxxx_rw_cmd_t", "union__25lcxxxx__rw__cmd__t.html", "union__25lcxxxx__rw__cmd__t" ],
    [ "_25lcxxxx_status_reg_bits_t", "struct__25lcxxxx__status__reg__bits__t.html", "struct__25lcxxxx__status__reg__bits__t" ],
    [ "_25lcxxxx_status_reg_t", "union__25lcxxxx__status__reg__t.html", "union__25lcxxxx__status__reg__t" ]
];