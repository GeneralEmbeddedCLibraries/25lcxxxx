var group____25_l_cxxxx =
[
    [ "_25lcxxxx_assemble_rw_cmd", "group____25_l_cxxxx.html#ga450f40c1c7c793c4ecbaaef655ceb1c4", null ],
    [ "_25lcxxxx_calc_num_of_sectors", "group____25_l_cxxxx.html#ga59422d02d52732e36cc74300d617a18c", null ],
    [ "_25lcxxxx_calc_transfer_size", "group____25_l_cxxxx.html#ga08f8da6422f3a8c1f993e592741ac7d4", null ],
    [ "_25lcxxxx_read_command", "group____25_l_cxxxx.html#ga90b1a8fc2cde43cf7a15316c65b5d38d", null ],
    [ "_25lcxxxx_read_status", "group____25_l_cxxxx.html#ga872c95ea201dca334aade78a2fb8b010", null ],
    [ "_25lcxxxx_read_wel_flag", "group____25_l_cxxxx.html#ga0464b6c5cc8352747f7e24f49b761f2f", null ],
    [ "_25lcxxxx_read_wip_flag", "group____25_l_cxxxx.html#ga6bf152d9b9536bded90b15226a016d06", null ],
    [ "_25lcxxxx_wait_for_write_process", "group____25_l_cxxxx.html#gae52e4fe0f931498af356eefbc52b64c0", null ],
    [ "_25lcxxxx_write_command", "group____25_l_cxxxx.html#ga80aa61ff26a4c65202a53589cc65fa2c", null ],
    [ "_25lcxxxx_write_disable", "group____25_l_cxxxx.html#gab253d50c3ad572852bc87517aed18afa", null ],
    [ "_25lcxxxx_write_enable", "group____25_l_cxxxx.html#ga26c49f2a498bfd538d594b2cd5862416", null ],
    [ "_25lcxxxx_write_status", "group____25_l_cxxxx.html#ga85e9ec07687f82e79ed2c164fc04c954", null ]
];