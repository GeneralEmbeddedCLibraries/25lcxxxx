var group___l_c_x_x_x_x___r_e_g_e_d_e_f =
[
    [ "_25lcxxxx_status_reg_bits_t", "struct__25lcxxxx__status__reg__bits__t.html", [
      [ "bp", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gaaccbd2a5e8a7f68cffeecae67b6c87d7", null ],
      [ "res", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gac16f015eede2270fa3f7217efc992d00", null ],
      [ "wel", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gab94751fc4f915f01369b87db72d0e247", null ],
      [ "wip", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga72e3fb6a65d40b0b25f75ba52926ebcf", null ],
      [ "wpen", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga5e75c42b432940c9492406df2eb35987", null ]
    ] ],
    [ "_25lcxxxx_status_reg_t", "union__25lcxxxx__status__reg__t.html", [
      [ "b", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gad98331d66a4188a4163838c07855e419", null ],
      [ "u", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga0d32dd6d63eb9497d1b3bbca6e2a614b", null ]
    ] ],
    [ "_25lcxxxx_isa_t", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gac7ddf44111ae849705f6634e0e123355", [
      [ "e25LCXXXX_ISA_READ", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355ac24fadd96f1327aacdd07d175c9b4b26", null ],
      [ "e25LCXXXX_ISA_WRITE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a797d8296e587e7973f0e73d70de70d63", null ],
      [ "e25LCXXXX_ISA_WREN", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a00d84e031ebe6eb6c2e3396d41216d6b", null ],
      [ "e25LCXXXX_ISA_WRDI", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a4cebef7aa17d10e86e949a6bbf0c272b", null ],
      [ "e25LCXXXX_ISA_RDST", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a167d60e98d3d1981207540d47c4c1577", null ],
      [ "e25LCXXXX_ISA_WDST", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a386684ac250af505af72b3bac2e35ee9", null ],
      [ "e25LCXXXX_ISA_PE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a5a3383e623c6a892df8780d2e70ec6b7", null ],
      [ "e25LCXXXX_ISA_SE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355ac7fc7f5c5942f073802f628befa062a9", null ],
      [ "e25LCXXXX_ISA_CE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355acebf2c1996010266dc848dc320910fbf", null ],
      [ "e25LCXXXX_ISA_RDID", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a17e0239b0f19a76bbb7bb01698c77db3", null ],
      [ "e25LCXXXX_ISA_DPD", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355aebb1254717525b63cd4f9df11b2b5b2d", null ]
    ] ],
    [ "e25LCXXXX_ISA_CE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355acebf2c1996010266dc848dc320910fbf", null ],
    [ "e25LCXXXX_ISA_DPD", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355aebb1254717525b63cd4f9df11b2b5b2d", null ],
    [ "e25LCXXXX_ISA_PE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a5a3383e623c6a892df8780d2e70ec6b7", null ],
    [ "e25LCXXXX_ISA_RDID", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a17e0239b0f19a76bbb7bb01698c77db3", null ],
    [ "e25LCXXXX_ISA_RDST", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a167d60e98d3d1981207540d47c4c1577", null ],
    [ "e25LCXXXX_ISA_READ", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355ac24fadd96f1327aacdd07d175c9b4b26", null ],
    [ "e25LCXXXX_ISA_SE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355ac7fc7f5c5942f073802f628befa062a9", null ],
    [ "e25LCXXXX_ISA_WDST", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a386684ac250af505af72b3bac2e35ee9", null ],
    [ "e25LCXXXX_ISA_WRDI", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a4cebef7aa17d10e86e949a6bbf0c272b", null ],
    [ "e25LCXXXX_ISA_WREN", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a00d84e031ebe6eb6c2e3396d41216d6b", null ],
    [ "e25LCXXXX_ISA_WRITE", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a797d8296e587e7973f0e73d70de70d63", null ],
    [ "b", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gad98331d66a4188a4163838c07855e419", null ],
    [ "bp", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gaaccbd2a5e8a7f68cffeecae67b6c87d7", null ],
    [ "res", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gac16f015eede2270fa3f7217efc992d00", null ],
    [ "u", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga0d32dd6d63eb9497d1b3bbca6e2a614b", null ],
    [ "wel", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#gab94751fc4f915f01369b87db72d0e247", null ],
    [ "wip", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga72e3fb6a65d40b0b25f75ba52926ebcf", null ],
    [ "wpen", "group___l_c_x_x_x_x___r_e_g_e_d_e_f.html#ga5e75c42b432940c9492406df2eb35987", null ]
];