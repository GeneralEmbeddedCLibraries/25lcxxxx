var 25lcxxxx_8c =
[
    [ "_25LCXXXX_MAX_ADDR", "group____25_l_c_x_x_x_x___a_p_i.html#ga6d1b6cc4043f86fe2ecf841996183c1e", null ],
    [ "_25LCXXXX_WAIT_WRITE_TIMEOUT_MS", "group____25_l_c_x_x_x_x___a_p_i.html#ga06c996774d657eeececa37ab987a1c17", null ],
    [ "_25lcxxxx_assemble_rw_cmd", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga450f40c1c7c793c4ecbaaef655ceb1c4", null ],
    [ "_25lcxxxx_calc_num_of_sectors", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga59422d02d52732e36cc74300d617a18c", null ],
    [ "_25lcxxxx_calc_transfer_size", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga08f8da6422f3a8c1f993e592741ac7d4", null ],
    [ "_25lcxxxx_deinit", "group____25_l_c_x_x_x_x___a_p_i.html#ga89f29a3eda3105cafe170c709616d71a", null ],
    [ "_25lcxxxx_init", "group____25_l_c_x_x_x_x___a_p_i.html#gaeaffadfad7d988069f9b7ecd0fdac4ad", null ],
    [ "_25lcxxxx_is_init", "group____25_l_c_x_x_x_x___a_p_i.html#ga81b69ce12c8d4450935feb4c38b07b98", null ],
    [ "_25lcxxxx_read", "group____25_l_c_x_x_x_x___a_p_i.html#ga7360cae913dabed716a7b18a01465d36", null ],
    [ "_25lcxxxx_read_command", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga90b1a8fc2cde43cf7a15316c65b5d38d", null ],
    [ "_25lcxxxx_read_status", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga872c95ea201dca334aade78a2fb8b010", null ],
    [ "_25lcxxxx_read_wel_flag", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga0464b6c5cc8352747f7e24f49b761f2f", null ],
    [ "_25lcxxxx_read_wip_flag", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga6bf152d9b9536bded90b15226a016d06", null ],
    [ "_25lcxxxx_set_protection", "group____25_l_c_x_x_x_x___a_p_i.html#ga0c39ebda111e401d6b2015b48da5a9be", null ],
    [ "_25lcxxxx_wait_for_write_process", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#gae52e4fe0f931498af356eefbc52b64c0", null ],
    [ "_25lcxxxx_write", "group____25_l_c_x_x_x_x___a_p_i.html#ga1bf7132dfd7ded3239dad75130e6cff9", null ],
    [ "_25lcxxxx_write_command", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga80aa61ff26a4c65202a53589cc65fa2c", null ],
    [ "_25lcxxxx_write_disable", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#gab253d50c3ad572852bc87517aed18afa", null ],
    [ "_25lcxxxx_write_enable", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga26c49f2a498bfd538d594b2cd5862416", null ],
    [ "_25lcxxxx_write_status", "group___k_e_r_n_e_l___f_u_n_c_t_i_o_n_s.html#ga85e9ec07687f82e79ed2c164fc04c954", null ],
    [ "gb_is_init", "group____25_l_c_x_x_x_x___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ]
];