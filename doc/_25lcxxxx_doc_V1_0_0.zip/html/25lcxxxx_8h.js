var 25lcxxxx_8h =
[
    [ "_25lcxxxx_protect_t", "group____25_l_c_x_x_x_x___a_p_i.html#ga95a2c1cc88fa2ed690bbad4f4251ffbb", [
      [ "e25LCXXXX_PROTECT_NONE", "group____25_l_c_x_x_x_x___a_p_i.html#gga95a2c1cc88fa2ed690bbad4f4251ffbbaab4bbe1069b9478166f53c5545ad087d", null ],
      [ "e25LCXXXX_PROTECT_UPPER_1_4", "group____25_l_c_x_x_x_x___a_p_i.html#gga95a2c1cc88fa2ed690bbad4f4251ffbbad226eafbbbcf6f8975595ea0debdce84", null ],
      [ "e25LCXXXX_PROTECT_UPPER_1_2", "group____25_l_c_x_x_x_x___a_p_i.html#gga95a2c1cc88fa2ed690bbad4f4251ffbbafd22693bb04d6ae3476a42a190cf20ab", null ],
      [ "e25LCXXXX_PROTECT_UPPER_ALL", "group____25_l_c_x_x_x_x___a_p_i.html#gga95a2c1cc88fa2ed690bbad4f4251ffbba1988198dabc7439d8876ce21c5790e2b", null ]
    ] ],
    [ "_25lcxxxx_status_t", "group____25_l_c_x_x_x_x___a_p_i.html#gac2ee6bc9e755f48b7e3541416c33e36f", [
      [ "e25LCXXXX_OK", "group____25_l_c_x_x_x_x___a_p_i.html#ggac2ee6bc9e755f48b7e3541416c33e36faebe77ecfb3074c8d0596c53faea2f249", null ],
      [ "e25LCXXXX_ERROR", "group____25_l_c_x_x_x_x___a_p_i.html#ggac2ee6bc9e755f48b7e3541416c33e36fa6e4d1938bbc6930f9d1ffaa4483287e0", null ],
      [ "e25LCXXXX_ERROR_SPI", "group____25_l_c_x_x_x_x___a_p_i.html#ggac2ee6bc9e755f48b7e3541416c33e36fa26e76f1db95743f51a5822972bf28a4b", null ],
      [ "e25LCXXXX_ERROR_INIT", "group____25_l_c_x_x_x_x___a_p_i.html#ggac2ee6bc9e755f48b7e3541416c33e36fa49edc2b668bf31795b9f4c55fca35eaf", null ],
      [ "e25LCXXXX_ERROR_ADDR", "group____25_l_c_x_x_x_x___a_p_i.html#ggac2ee6bc9e755f48b7e3541416c33e36fa300fdde4a78851ca831ce6183c01b549", null ]
    ] ],
    [ "_25lcxxxx_deinit", "group____25_l_c_x_x_x_x___a_p_i.html#ga89f29a3eda3105cafe170c709616d71a", null ],
    [ "_25lcxxxx_init", "group____25_l_c_x_x_x_x___a_p_i.html#gaeaffadfad7d988069f9b7ecd0fdac4ad", null ],
    [ "_25lcxxxx_is_init", "group____25_l_c_x_x_x_x___a_p_i.html#ga81b69ce12c8d4450935feb4c38b07b98", null ],
    [ "_25lcxxxx_read", "group____25_l_c_x_x_x_x___a_p_i.html#ga7360cae913dabed716a7b18a01465d36", null ],
    [ "_25lcxxxx_set_protection", "group____25_l_c_x_x_x_x___a_p_i.html#ga0c39ebda111e401d6b2015b48da5a9be", null ],
    [ "_25lcxxxx_write", "group____25_l_c_x_x_x_x___a_p_i.html#ga1bf7132dfd7ded3239dad75130e6cff9", null ]
];