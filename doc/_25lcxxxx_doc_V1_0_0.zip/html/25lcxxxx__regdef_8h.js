var 25lcxxxx__regdef_8h =
[
    [ "_25lcxxxx_isa_t", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#gac7ddf44111ae849705f6634e0e123355", [
      [ "e25LCXXXX_ISA_READ", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355ac24fadd96f1327aacdd07d175c9b4b26", null ],
      [ "e25LCXXXX_ISA_WRITE", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a797d8296e587e7973f0e73d70de70d63", null ],
      [ "e25LCXXXX_ISA_WREN", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a00d84e031ebe6eb6c2e3396d41216d6b", null ],
      [ "e25LCXXXX_ISA_WRDI", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a4cebef7aa17d10e86e949a6bbf0c272b", null ],
      [ "e25LCXXXX_ISA_RDST", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a167d60e98d3d1981207540d47c4c1577", null ],
      [ "e25LCXXXX_ISA_WDST", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a386684ac250af505af72b3bac2e35ee9", null ],
      [ "e25LCXXXX_ISA_PE", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a5a3383e623c6a892df8780d2e70ec6b7", null ],
      [ "e25LCXXXX_ISA_SE", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355ac7fc7f5c5942f073802f628befa062a9", null ],
      [ "e25LCXXXX_ISA_CE", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355acebf2c1996010266dc848dc320910fbf", null ],
      [ "e25LCXXXX_ISA_RDID", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355a17e0239b0f19a76bbb7bb01698c77db3", null ],
      [ "e25LCXXXX_ISA_DPD", "group____25_l_c_x_x_x_x___r_e_g_e_d_e_f.html#ggac7ddf44111ae849705f6634e0e123355aebb1254717525b63cd4f9df11b2b5b2d", null ]
    ] ]
];